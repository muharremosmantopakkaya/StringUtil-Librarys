package tr.edu.altinbas.util.numeric;

import java.util.ArrayList;
import java.util.Random;

public final class NumberUtil {
    private NumberUtil() {
    }

    public static int digitsSum(int val) {
        int sum = 0;

        while (val != 0) {
            sum += val % 10;
            val /= 10;
        }

        return Math.abs(sum);
    }


    public static long factorial(int n) {
        long result = 1;

        for (int i = 2; i <= n; ++i)
            result *= i;

        return result;
    }

    public static boolean isArmstrong(int val) {
        throw new UnsupportedOperationException("isArmstrong");
    }

    public static boolean isPrime(long val) {
        if (val <= 1)
            return false;

        if (val % 2 == 0)
            return val == 2;

        if (val % 3 == 0)
            return val == 3;

        if (val % 5 == 0)
            return val == 5;

        if (val % 7 == 0)
            return val == 7;

        for (long i = 11; i * i <= val; i += 2)
            if (val % i == 0)
                return false;

        return true;
    }


    public static int array(int[] a) {
        int toplam = 0;
        for(int i=0; i<a.length; i++) {
            toplam = toplam+a[i];
        }
        return toplam/a.length;
    }


    }