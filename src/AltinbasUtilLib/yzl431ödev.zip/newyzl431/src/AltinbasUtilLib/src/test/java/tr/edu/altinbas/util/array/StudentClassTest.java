package tr.edu.altinbas.util.array;

import static org.junit.Assert.*;

import junit.framework.Assert;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class StudentClassTest {
   public StudentClassTest()
   {

   }
   @BeforeClass
    public static void setUpClass()
   {
    System.out.println(" @BeforeClass Method");
   }
   @AfterClass
    public static void tearDownClass()
   {
       System.out.println(" @AfterClass Method");
   }
   @Before
    public void setUp()
   {
       System.out.println(" @After Classs Method");

   }
   @After
    public void tearDown()
   {
       System.out.println(" @AftereClasss Method");

   }

   @Test
    public void testGetId()
   {

       System.out.println("getId");
       StudentClass instance = new StudentClass();

       int expResult=0;
       int result= instance.getId();

       assertEquals(expResult, result);
    //  fail("The test case is a pr Basarısız");
   }

   @Test

    public void testSetId()
   {
       System.out.println("setId");
       int id=0;
       StudentClass instance=new StudentClass();
       instance.setId(id);

     //  fail("The test case is a prototyee Basarısız");
   }
}