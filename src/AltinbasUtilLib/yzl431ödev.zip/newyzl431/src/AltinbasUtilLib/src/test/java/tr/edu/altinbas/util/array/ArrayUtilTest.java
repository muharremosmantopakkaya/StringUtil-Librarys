package tr.edu.altinbas.util.array;

import org.junit.Test;

import static org.junit.Assert.*;

public class ArrayUtilTest {

    @Test
    public void getRandomArray() {
    }

    @Test
    public void getRandomMatrix() {
    }
}